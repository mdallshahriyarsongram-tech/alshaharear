SONGRAM PORTFOLIO — NETLIFY READY

This package is prepared for Netlify drag-and-drop deployment.

IMPORTANT:
- Keep index.html, style.css, script.js, netlify.toml and the assets folder together.
- Do NOT upload only index.html.
- You can upload this ZIP directly to Netlify Drop, or extract it and upload the whole folder.

DEPLOY:
1. Go to https://app.netlify.com/drop
2. Log in to your Netlify account.
3. Drag this ZIP file (or the extracted folder) into the Drop area.
4. Wait for the deploy to finish.
5. Open the new .netlify.app URL.

The site uses absolute paths for CSS and the portrait image, and netlify.toml explicitly publishes the project root.
YouTube embeds require an internet connection.
